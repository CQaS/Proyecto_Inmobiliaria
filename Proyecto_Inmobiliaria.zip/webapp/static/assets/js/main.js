// document.querySelector(".menu-btn").addEventListener("click", () => {
//     document.querySelector(".nav-menu").classList.toggle("show");
//   });

//   ScrollReveal().reveal('.showcase');
//   ScrollReveal().reveal('.news-cards', { delay: 500 });
//   ScrollReveal().reveal('.cards-banner-one', { delay: 500 });
//   ScrollReveal().reveal('.cards-banner-two', { delay: 500 });

//Barra de busqueda
// Obtener los elementos del DOM
// let searchInput = document.getElementById('search-input');
// let searchButton = document.getElementById('search-button');
// let searchResults = document.getElementById('search-results');

// Agregar un evento al botón de búsqueda
// searchButton.addEventListener('click', function() {
// Obtener el valor de búsqueda ingresado por el usuario
// let searchTerm = searchInput.value;

// Aquí puedes implementar la lógica para realizar la búsqueda, como realizar una solicitud AJAX a un servidor o filtrar elementos en el cliente

// Limpiar los resultados anteriores
// searchResults.innerHTML = '';

// Mostrar los resultados de la búsqueda
//   let resultElement = document.createElement('p');
//   resultElement.textContent = 'Resultado 1';
//   searchResults.appendChild(resultElement);

//   resultElement = document.createElement('p');
//   resultElement.textContent = 'Resultado 2';
//   searchResults.appendChild(resultElement);
// });