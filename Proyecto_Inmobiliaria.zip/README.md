inmobiliaria
Proyecto Inmobiliaria

Virginia: esta trabajando sobre el contrato que hay que generar sobre pdf

Esteban: necesitamos que realices el CRUD de las propiedades, clientes y empleados, en la carpeta servicios (esta creada). La BASE DE DATOS esta hecha en MySQL (no esta conectada y esta en revison, porque todos los dias nos pasan un cambio) Las tablas que llevan CRUD son: propiedades clientes empleados

Dalila: esta trabajando sobre el front de la pagina

ESPECIFICACIONES PAGINA WEB INMOBILIARIA

- HOME: - HEADER (LOGO) - GALERIA DE DESTACADOS - FILTROS POR TIPO DE OPEARCION Y POR TIPO DE PROPIEDAD - GALERIA FILTRADA - QUIENES SOMOS - FORMULARIO DE CONTACTO - FOOTER (REDES SOCIALLES)
- PAGINA DE LA PROPIEDAD SELECCIONADA EN EL HOME: - Va a tener la siguiente info:
  DIRECCION
  TIPO DE OPERACION
  VALOR
  FOTOS DETALLES DE LA PROPIEDAD

        INFORMACION BASICA              FORMULARIO DE CONTACTO

        UBICACION (GOOGLE MAP)

  - SERVICE: - USUARIO Y CONTRASEÑA (para la administradora) - CRUD PROPIEDADES - CRUD CLIENTES - CRUD EMPLEADOS - CONTRATO (editarlo, tomar los datos de la base de datos y generar el pdf)

**\* VER EN QUE PARTE UBICAMOS PANEL/TABLERO MOSTRANDO DISPONIBILIDAD (EN ALQUILERES TEMPORARIOS) DE CADA PROPIEDAD \*\*\*\***

MEET
14/09/23

Propiedades
Campos para agregar a la BD
→ Nº referencia

- Estado (disponibilidad / indisponible) es cuando el dueño alquila queda indisponible
- Clave puerta ingreso
- Clave Wi-Fi
- Valor del precio de la limpieza

Modificar
→ Destacado por Exclusividad

Campos a sacar
→ Antiguedad

Pedir listado de servicios (Maria Eugenia)

Clientes

- ver C.P.F. (cuil es numerico) Ejemplo: Número de CPF: 123.456.789-09
  R.G. (DNI Brasil) Ejemplo: Número de R.G.: 1234567 SSP/SP
  (C.P.F. y R.G. se usan cuando son brasileros)
  R.N.M. (extranjeros radicados en brasil) Ejemplo: Número de R.N.M.: 2023-123456
  Nº Cedula identidad (Uruguay y Paraguay)

→ Cambiar inquilino por locatario

- Rendicion de gastos a los propietarios por ejemplo Mantenimiento

Contrato

- LLeva solo nombre Propietario
- Precios editables
- Reserva
- Impresion de contrato

- Forma de pago (campo editable)

Empleados

- Calculo de pagos de limpieza y emision de recibo para imprimir y descontar lo que se
  le paga
- pedir listado de puestos de trabajo
